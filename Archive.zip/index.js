const express = require('express')
const app = express()


// const 

const port = [...process.argv][2];
app.use((req, res, next) => {
	console.log(req.port);
	if (req.query.r === '' && port === '8080') {
		console.log('redirect header!');
		res.setHeader('Location', `http://localhost:8181${req.url}`);
		res.sendStatus(301);
	} else {
		if (req.query.h === '') {
			console.log('content disposition header!');
			res.setHeader('Content-Disposition', 'attachment');
		}
		next();
	}
	
});

app.use('/files', express.static('files'));

app.get('*', (req, res) => {
	res.write(`
		<style> div > div { flex: 1; padding: 0 20px;} </style>
		<h1 style="text-align: center">'download' attribute tester</h1>

		
		<div style="display: flex;">
			<div>
				<h2>Same origin</h2> 
				<h3>No download attribute, no header</h3>
				<a href="/files/img.png" target="_blank">.png</a>
				<a href="/files/file1.txt" target="_blank">.txt</a>
				<a href="/files/bob.log" target="_blank">.log</a>

				<h3>download attribute, no header</h3>
				<a href="/files/img.png" download target="_blank">.png</a>
				<a href="/files/file1.txt" download target="_blank">.txt</a>
				<a href="/files/bob.log" download target="_blank">.log</a>

				<h3>No download attribute, header</h3>
				<a href="/files/img.png?h" target="_blank">.png</a>
				<a href="/files/file1.txt?h" target="_blank">.txt</a>
				<a href="/files/bob.log?h" target="_blank">.log</a>
			</div>

			<div>
				<h2>Other origin</h2> 
				<h3>No download attribute, no header</h3>
				<a href="http://localhost:8181/files/img.png" target="_blank">.png</a>
				<a href="http://localhost:8181/files/file1.txt" target="_blank">.txt</a>
				<a href="http://localhost:8181/files/bob.log" target="_blank">.log</a>

				<h3>download attribute, no header</h3>
				<a href="http://localhost:8181/files/img.png" download target="_blank">.png</a>
				<a href="http://localhost:8181/files/file1.txt" download target="_blank">.txt</a>
				<a href="http://localhost:8181/files/bob.log" download target="_blank">.log</a>

				<h3>No download attribute, header</h3>
				<a href="http://localhost:8181/files/img.png?h" target="_blank">.png</a>
				<a href="http://localhost:8181/files/file1.txt?h" target="_blank">.txt</a>
				<a href="http://localhost:8181/files/bob.log?h" target="_blank">.log</a>
			</div>

			<div>
				<h2>Redirect to different origin</h2> 
				<h3>No download attribute, no header</h3>
				<a href="http://localhost:8080/files/img.png?r" target="_blank">.png</a>
				<a href="http://localhost:8080/files/file1.txt?r" target="_blank">.txt</a>
				<a href="http://localhost:8080/files/bob.log?r" target="_blank">.log</a>

				<h3>download attribute, no header</h3>
				<a href="http://localhost:8080/files/img.png?r" download target="_blank">.png</a>
				<a href="http://localhost:8080/files/file1.txt?r" download target="_blank">.txt</a>
				<a href="http://localhost:8080/files/bob.log?r" download target="_blank">.log</a>

				<h3>No download attribute, header</h3>
				<a href="http://localhost:8080/files/img.png?h&r" target="_blank">.png</a>
				<a href="http://localhost:8080/files/file1.txt?h&r" target="_blank">.txt</a>
				<a href="http://localhost:8080/files/bob.log?h&r" target="_blank">.log</a>
			</div>
		</div>
	
	
	`);
    res.end()
})


console.log(`running in ${port}`);
app.listen(port);
